//
//  ViewController.swift
//  Tipsy
//
//  Created by Angela Yu on 09/09/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class CalculatorViewController: UIViewController {

  @IBOutlet weak var billTextField: UITextField!
  @IBOutlet weak var zeroPctButton: UIButton!
  @IBOutlet weak var tenPctButton: UIButton!
  @IBOutlet weak var twentyPctButton: UIButton!
  @IBOutlet weak var splitNumberLabel: UILabel!

  var tipPercent = 0.10
  var billTotal = 0.0
  var tipAmount = "0.00"
  var numberOfPeople = 2

  @IBAction func tipChanged(_ sender: UIButton) {

    zeroPctButton.isSelected = false
    tenPctButton.isSelected = false
    twentyPctButton.isSelected = false

    sender.isSelected = true

    let buttonTitle = sender.currentTitle!
    let buttonTitleMinusPercentSign = String(buttonTitle.dropLast())
    let buttonTitleAsNumber = Double(buttonTitleMinusPercentSign)!

    tipPercent = buttonTitleAsNumber / 100

    billTotal = Double(billTextField.text!)!
    let formattedBillText = String(format: "$%.2f", billTotal)

    billTextField.text = formattedBillText

    billTextField.endEditing(true)

  }

  @IBAction func stepperValueChanged(_ sender: UIStepper) {

    sender.minimumValue = 2
    sender.stepValue = 1

    numberOfPeople = Int(sender.value)

    splitNumberLabel.text = String(format: "%.0f", sender.value)

  }

  @IBAction func calculatePressed(_ sender: UIButton) {

    let bill = Float(billTotal)
    let tip = Float(tipPercent)
    let splitNumber = Float(splitNumberLabel.text!) ?? Float(2)
    let tipTotal = ((bill * tip) + bill) / splitNumber

    tipAmount = String(format: "$%.2f", tipTotal)

    self.performSegue(withIdentifier: "goToResults", sender: self)

  }

  @IBAction func editBillTotal(_ sender: Any) {

    _ = billTextField.isEditing
    _ = billTextField.text = ""
    _ = billTextField.text ?? "0.00"

  }

  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

    if segue.identifier == "goToResults" {

      let destinationVC = segue.destination as! ResultsViewController
      
      destinationVC.tip = Int(tipPercent * 100)
      destinationVC.split = numberOfPeople
      destinationVC.result = self.tipAmount

    }

  }

}

