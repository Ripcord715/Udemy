//
//  Dicee_SwiftUIApp.swift
//  Dicee-SwiftUI
//
//  Created by Bobby McBride on 8/22/22.
//

import SwiftUI

@main
struct Dicee_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
