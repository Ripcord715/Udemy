//
//  ContentView.swift
//  BobbyCard
//
//  Created by Bobby McBride on 8/22/22.
//

import SwiftUI

struct ContentView: View {

  var body: some View {

    ZStack {

      Color(red: 0.20, green: 0.60, blue: 0.86)
        .edgesIgnoringSafeArea(.all)

      VStack {

        Image("Bobby")
          .resizable()
          .aspectRatio(contentMode: .fit)
          .frame(width: 150, height: 200)
          .clipShape(Circle())
          .overlay(
            Circle().stroke(Color.white, lineWidth: 5)
          )

        Text("Bobby McBride")
          .font(Font.custom("Press Start 2P", size: 40, relativeTo: .body))
          .bold()
        .foregroundColor(.white)

        Text("iOS Developer")
          .foregroundColor(.white)
          .font(.system(size: 25))

        Divider()

        InfoView(
          text: "(714) 724-7216",
          imageName: "iphone",
          imageColor: .green
        )

        InfoView(
          text: "rmcbride81@gmail.com",
          imageName: "envelope.fill",
          imageColor: .green
        )

      }

    }

  }

}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
      ContentView()
    }
}


