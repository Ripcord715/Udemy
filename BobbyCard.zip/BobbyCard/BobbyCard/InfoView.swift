//
//  InfoView.swift
//  BobbyCard
//
//  Created by Bobby McBride on 8/22/22.
//

import SwiftUI

struct InfoView: View {

  let text: String
  let imageName: String
  let imageColor: Color

  var body: some View {
    RoundedRectangle(cornerRadius: 45)
      .fill(.white)
      .frame(height: 35)
      .overlay( HStack {
        Image(systemName: imageName)
          .foregroundColor(imageColor)
        Text(text)
      })
      .padding(.all)
  }

}

struct InfoView_Previews: PreviewProvider {

  static var previews: some View {
    InfoView(
      text: "Hello",
      imageName: "phone.fill",
      imageColor: .purple)
    .previewLayout(.sizeThatFits)
  }

}
