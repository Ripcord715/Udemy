//
//  BobbyCardApp.swift
//  BobbyCard
//
//  Created by Bobby McBride on 8/22/22.
//

import SwiftUI

@main
struct BobbyCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
