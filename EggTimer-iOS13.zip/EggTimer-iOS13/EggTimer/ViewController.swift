//
//  ViewController.swift
//  EggTimer
//
//  Created by Angela Yu on 08/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

  var player: AVAudioPlayer!

//  var eggTimes = ["Soft": 300, "Medium": 420, "Hard":720]
  var eggTimes = ["Soft": 3, "Medium": 4, "Hard":5]

  var timer: Timer?

  var totalTime = 0
  var secondsPassed = 0

  @IBOutlet var progressBar: UIProgressView!
  @IBOutlet var timerDisplay: UILabel!

  @IBAction func hardnessSelected(_ sender: UIButton) {

    timer?.invalidate()

    let hardness = sender.currentTitle!

    totalTime = eggTimes[hardness]!

    self.progressBar.progress = 0
    self.secondsPassed = 0
    self.timerDisplay.text = "How do you like your eggs?"

    timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [self](timer) in
      if secondsPassed < totalTime {

        secondsPassed += 1

        let percentageProgress = Float(secondsPassed) / Float(totalTime)

        progressBar.setProgress(percentageProgress, animated: true)

        if (progressBar.progress == 1 ) {

          timerDisplay.text = "Done!"

          playSound(soundName: "alarm_sound")

        }

      } else {

        timer.invalidate()

      }

    }

  }

  func playSound(soundName: String) {

      let url = Bundle.main.url(forResource: soundName, withExtension: "mp3")

    do{

      try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
      try AVAudioSession.sharedInstance().setActive(true)
      player = try! AVAudioPlayer(contentsOf: url!)
      player.prepareToPlay()
      player.volume = 1.0
      player.play()
    } catch let error {}

    }

}
