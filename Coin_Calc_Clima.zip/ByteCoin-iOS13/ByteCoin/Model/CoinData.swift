//
//  CoinData.swift
//  ByteCoin
//
//  Created by Bobby McBride on 7/27/22.
//  Copyright © 2022 The App Brewery. All rights reserved.
//

import Foundation

struct CoinData: Codable {

  let rate: Double

}
