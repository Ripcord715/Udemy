//
//  H4X0R_NewsApp.swift
//  H4X0R News
//
//  Created by Bobby McBride on 8/26/22.
//

import SwiftUI

@main
struct H4X0R_NewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
