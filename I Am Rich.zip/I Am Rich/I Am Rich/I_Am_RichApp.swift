//
//  I_Am_RichApp.swift
//  I Am Rich
//
//  Created by Bobby McBride on 8/19/22.
//

import SwiftUI

@main
struct I_Am_RichApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
